package com.android.chaldhal.listeners

import android.view.View
import com.android.chaldhal.models.Result

interface HomeDataListener {
    fun onItemClick(position: Int, item: Result?, view: View)
}