package com.android.chaldhal.ui.fragments.home

import PAGE_SIZE_LIMIT
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.android.chaldhal.datasource.RemotePagingSource
import com.android.chaldhal.models.ApiResponse
import com.android.chaldhal.models.Result
import com.android.chaldhal.network.ApiService
import com.android.chaldhal.network.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val apiService: ApiService) : ViewModel() {

    private val _getHomeData: MutableLiveData<Resource<ApiResponse>> =
        MutableLiveData()
    val getHomeData: LiveData<Resource<ApiResponse>>
        get() = _getHomeData

    fun homeDataRequest(): Flow<PagingData<Result>> =
        Pager(PagingConfig(pageSize = PAGE_SIZE_LIMIT)) {
            RemotePagingSource(apiService)
        }.flow

}