const val HEADER_CACHE_CONTROL = "Cache-Control"
const val HEADER_PRAGMA = "Pragma"
const val PAGE_SIZE_LIMIT = 50
const val TITLE = "TITLE"
const val FIRST = "FIRST"
const val LAST = "LAST"
