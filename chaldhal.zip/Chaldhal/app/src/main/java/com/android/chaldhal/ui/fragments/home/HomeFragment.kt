package com.android.chaldhal.ui.fragments.home

import FIRST
import LAST
import TITLE
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.Navigation
import com.android.chaldhal.R
import com.android.chaldhal.adapter.HomeDataAdapter
import com.android.chaldhal.base.BaseFragment
import com.android.chaldhal.databinding.FragmentHomeBinding
import com.android.chaldhal.listeners.HomeDataListener
import com.android.chaldhal.models.Result
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class HomeFragment : BaseFragment<FragmentHomeBinding>(),HomeDataListener {

    private val homeViewModel: HomeViewModel by viewModels()
    private var homeDataAdapter:HomeDataAdapter = HomeDataAdapter(this)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        homeDataRequest()
        observeHomeData()
        initRecyclerView()

    }

    private fun initRecyclerView() {
        binding.rvHome.adapter = homeDataAdapter
    }

    private fun observeHomeData() {
        lifecycleScope.launch {
            homeViewModel.homeDataRequest().collectLatest {
                homeDataAdapter.submitData(it)
            }
        }
    }

    private fun homeDataRequest() {
        homeViewModel.homeDataRequest()
    }




    override fun onItemClick(position: Int, item: Result?, view: View) {
        val bundle = Bundle()
        bundle.putString(TITLE,item?.name?.title)
        bundle.putString(FIRST,item?.name?.first)
        bundle.putString(LAST,item?.name?.last)
        Navigation.findNavController(view).navigate(R.id.action_homeFragment_to_detailsFragment,bundle)
    }

    override fun getFragmentBinding(inflater: LayoutInflater, container: ViewGroup?) =
        FragmentHomeBinding.inflate(inflater, container, false)
}